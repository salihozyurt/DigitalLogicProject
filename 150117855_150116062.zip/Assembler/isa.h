#if !defined(ISA_H)
#define ISA_H

#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#define ISA_LENGTH 16

typedef enum Boolean Boolean;
typedef struct OpCodeUnit OpCodeUnit;
typedef OpCodeUnit * OpCodeUnitPtr;

enum Boolean
{
    FALSE, TRUE
};
struct OpCodeUnit
{
    char name[5];
    char code[5];
};

const char default_op_code_name[] = "None";
char current_op_code[10];

OpCodeUnit OP_CODE_UNITS[ISA_LENGTH];

OpCodeUnit _OpCodeUnit(char name[], char code[])
{
    if (strlen(current_op_code) == 0) strcpy(current_op_code, default_op_code_name);
    OpCodeUnitPtr new_op_code_unit_ptr = (OpCodeUnitPtr) malloc(sizeof(OpCodeUnit));
    if (new_op_code_unit_ptr != NULL)
    {
        strcpy(new_op_code_unit_ptr->name, name);
        strcpy(new_op_code_unit_ptr->code, code);
        return *new_op_code_unit_ptr;
    }
    else
    {
        _OpCodeUnit(code, name);
    }
}

void init_op_codes()
{
    OpCodeUnit replica[] = {_OpCodeUnit("ADD", "0000"), _OpCodeUnit("AND", "0001"), _OpCodeUnit("OR", "0010"), _OpCodeUnit("XOR", "0011"),
    _OpCodeUnit("ADDI", "0100"), _OpCodeUnit("ANDI", "0101"), _OpCodeUnit("ORI", "0110"), _OpCodeUnit("XORI", "0111"), _OpCodeUnit("JUMP", "1000"), _OpCodeUnit("LD", "1001"),
    _OpCodeUnit("ST", "1010"), _OpCodeUnit("BEQ", "1011"), _OpCodeUnit("BLT", "1100"), _OpCodeUnit("BGT", "1101"), _OpCodeUnit("BLE", "1110"), _OpCodeUnit("BGE", "1111")};
    for (int i = 0; i < ISA_LENGTH; ++i)
    {
        OP_CODE_UNITS[i] = replica[i];
    }
}

void detect_op_code(char command[])
{
    char input_op_code_name[10];
    sscanf(command, "%s", input_op_code_name);
    for (int i = 0; i < ISA_LENGTH; ++i)
    {
        if (!strcmp(input_op_code_name, OP_CODE_UNITS[i].name))
        {
            strcpy(current_op_code, OP_CODE_UNITS[i].code);
            puts("Opcode detected succesfully.");
            return;
        }
    }
    puts("Opcode not detected.");
    fprintf(stderr, "%s\n", "Possibly entered an undefined opcode.");
}

#endif // ISA_H
