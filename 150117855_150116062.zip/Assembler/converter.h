//
// title "Converter Library"
// author Salih ÖZYURT
//

#include <stdlib.h>
#include <string.h>
#include <math.h>

#define SIZE 255

#ifndef DIGITALLOGICPROJECT_CONVERTER_H
#define DIGITALLOGICPROJECT_CONVERTER_H

#endif //DIGITALLOGICPROJECT_CONVERTER_H

char* convertValue(char currentType, char convertType, char *Input);
char* decimalToAnytype(char *Input, char type);
char* binaryToAnytype(char *Input, char type);
char* hexadecimalToAnytype(char *Input, char type);
char* octalToAnytype(char *Input, char type);
char* Itoa(int value, int radix);

// B = binary , D = decimal , H = hexadecimal , O = octal
// We must right D for currentType and right B for convertType if we want to convert decimal to binary.
// CurrentType and Input must be same type.
char* convertValue(char currentType, char convertType, char *Input){
    switch(currentType){
        case 'B':
            return binaryToAnytype(Input,convertType);
        case 'D':
            return decimalToAnytype(Input,convertType);
        case 'H':
            return hexadecimalToAnytype(Input,convertType);
        case 'O':
            return octalToAnytype(Input,convertType);
        default:
            perror("Wrong Current Type.");
            exit(EXIT_FAILURE);
    }
}

char* decimalToAnytype(char *Input, char type){
    int value = atoi(Input);
    char convertedValue[SIZE];
    switch (type){
        case 'B':
            return Itoa(value, 2);
        case 'H':
            return Itoa(value, 16);
        case 'O':
            return Itoa(value, 8);
        default:
            perror("Wrong Convert Type.");
            exit(EXIT_FAILURE);
    }
}

char* binaryToAnytype(char *Input, char type){
    int length = (int) strlen(Input);
    int decimal = 0;
    int index = 0 , temp = 0;
    char forHexa[SIZE] = "";
    for (int i = 0; i <= length-1 ; i++) {
        if (Input[i] == '1')
            decimal += (int) pow(2,length-i-1);
    }
    switch (type){
        case 'D':
            return Itoa(decimal, 10);
        case 'H':
            while(index < length){
                char subbuff[5];
                memcpy( subbuff, &Input[temp*4], 4 );
                subbuff[4] = '\0';
                index += 4;
                temp++;
                strcat(forHexa, Itoa(atoi(binaryToAnytype(strdup(subbuff), 'D')), 16));
            }
            return strdup(forHexa);
        case 'O':
            return Itoa(decimal, 8);
        default:
            perror("Wrong Convert Type.");
            exit(EXIT_FAILURE);
    }
}

char* hexadecimalToAnytype(char *Input, char type){
    int length = strlen(Input);
    int decimal = 0;
    int decimalTemp;
    int inputTemp;
    for (int i = 0; i <= length-1 ; i++) {
        inputTemp = Input[i];
        if(inputTemp >= 97 && inputTemp <= 102){
            decimalTemp = inputTemp - 87;
            decimal += decimalTemp * (int) pow(16,length-i-1);
        } else if (inputTemp >= 65 && inputTemp <= 70){
            decimalTemp = inputTemp - 55;
            decimal += decimalTemp * (int) pow(16,length-i-1);
        } else {
            decimalTemp = inputTemp - 48;
            decimal += decimalTemp * (int) pow(16,length-i-1);
        }
    }
    switch (type){
        case 'B':
            return Itoa(decimal, 2);
        case 'D':
            return Itoa(decimal, 10);
        case 'O':
            return Itoa(decimal, 8);
        default:
            perror("Wrong Convert Type.");
            exit(EXIT_FAILURE);
    }
}

char* octalToAnytype(char *Input, char type){
    int length = strlen(Input);
    int decimal = 0;
    int decimalTemp;
    int inputTemp;
    for (int i = 0; i <= length-1 ; i++) {
        inputTemp = Input[i];
        if(inputTemp >= 48 && inputTemp <= 55){
            decimalTemp = inputTemp - 48;
            decimal += decimalTemp * (int) pow(8,length-i-1);
        }
    }
    switch (type){
        case 'B':
            return Itoa(decimal, 2);
        case 'D':
            return Itoa(decimal, 10);
        case 'H':
            return Itoa(decimal, 16);
        default:
            perror("Wrong Convert Type.");
            exit(EXIT_FAILURE);
    }

}

char *strrev(char *str)
{
      char *p1, *p2;
      if (! str || ! *str)
            return str;
      for (p1 = str, p2 = str + strlen(str) - 1; p2 > p1; ++p1, --p2)
      {
            *p1 ^= *p2;
            *p2 ^= *p1;
            *p1 ^= *p2;
      }
      return str;
}

char* Itoa(int value, int radix)
{ 
    if (radix == 10)
    {
        char *str_value = (char *) malloc(SIZE);
        sprintf(str_value, "%d", value);
        return str_value;
    }
    int index = 0, mod;
    char return_value[SIZE];
    while(value >= radix) {
        mod = value % radix;
        return_value[index++] = (mod > 9) ? ('a' + mod - 10) : ('0' + mod);
        value /= radix;
    }
    return_value[index++] = (value > 9) ? ('a' + value - 10) : ('0' + value);
    return_value[index] = '\0';
    strrev(return_value);
    char *mimic = (char*)(malloc(SIZE));
    memcpy(mimic,return_value,strlen(return_value));
    return mimic;
}