#include "encrypter.h"

int main() {
    encrypt();
    return EXIT_SUCCESS;
}