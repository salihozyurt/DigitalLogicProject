#if !defined(FILE_IO_H)
#define FILE_IO_H

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#define STANDARD_READ_SIZE 256

typedef enum FileMode FileMode;
typedef enum PrintMode PrintMode;

enum FileMode
{
    WRITE, APPEND
};

enum PrintMode
{
    RAW, NEWLINE
};

char read_filename[10];
char write_filename[10];
FILE *write_fptr;
FILE *read_fptr;

void change_write_filename(char new_filename[])
{
    strcpy(write_filename, new_filename);
}

void write_in_file(char data[], FileMode file_mode, PrintMode print_mode)
{
    char file_mode_str[10];
    switch (file_mode)
    {
    case WRITE:
        strcpy(file_mode_str, "w");
        break;
    case APPEND:
        strcpy(file_mode_str, "a");
        break;
    default:
        break;
    }
    if (write_fptr == NULL)
    {
        write_fptr = fopen(write_filename, file_mode_str);
    }
    char print_token[10];
    switch (print_mode)
    {
    case RAW:
        strcpy(print_token, "");
        break;
    case NEWLINE:
        strcpy(print_token, "\n");
    default:
        break;
    }
    fprintf(write_fptr, "%s%s", data, print_token);
}

void change_read_filename(char new_filename[])
{
    strcpy(read_filename, new_filename);
}

char * read_line()
{
    char line_data[STANDARD_READ_SIZE];
    if (read_fptr == NULL)
    {
        read_fptr = fopen(read_filename, "r");
    }
    if (fscanf(read_fptr, "%[^\n]%*c", line_data) != EOF)
    {
        return strdup(line_data);
    }
    else
    {
        return NULL;   
    }
}

void clear_write_cache()
{
    fclose(write_fptr);
    write_fptr = NULL;
}

void clear_read_cache()
{
    fclose(read_fptr);
    read_fptr = NULL;
}

#endif // FILE_IO_H
