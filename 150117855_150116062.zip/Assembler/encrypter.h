//
// title "Encrypter Library"
// authors Salih ÖZYURT & Muhammed Bera KOÇ
//

#include "isa.h"
#include "converter.h"
#include "file_io.h"

#ifndef DIGITALLOGICPROJECT_ENCRYPTER_H
#define DIGITALLOGICPROJECT_ENCRYPTER_H

char * convert_binary_and_expand(char input[], Boolean is_negative, int limit);

void encrypt() {
    int opCodeValue;
    char outputLineData[SIZE] = "";
    init_op_codes();
    change_write_filename("test_output.txt");
    change_read_filename("test_input.txt");
    char *input_data;
    write_in_file("", WRITE, RAW);
    while ((input_data = read_line()) != NULL)
    {
        strcpy(outputLineData,"");
        detect_op_code(input_data);
        opCodeValue = atoi(convertValue('B','D',current_op_code));
        if(opCodeValue >= 0 && opCodeValue < 4){
            strcat(outputLineData, current_op_code);
            const char delimiter[2] = " ";
            char *token;
            token = strtok(input_data,delimiter);
            token = strtok(NULL, delimiter);
            while (token != NULL)
            {
                int length = strlen(token);
                if (token[length - 1] == ',')
                {
                    token[length - 1] = '\0';
                }
                char *subToken = (char*) malloc(SIZE);
                memcpy( subToken, &token[1], strlen(token) );
                subToken[strlen(token)] = '\0';
                subToken = convert_binary_and_expand(subToken, FALSE, 4);
                strcat(outputLineData,subToken);
                token = strtok(NULL, delimiter);
            }
            strcat(outputLineData, "0");
            strcat(outputLineData, "0");
        }
        else if (opCodeValue >=4 && opCodeValue <= 7)
        {
            strcat(outputLineData, current_op_code);
            const char delimiter[2] = " ";
            char *token;
            int limit;
            Boolean is_negative = FALSE;
            token = strtok(input_data, delimiter);
            token = strtok(NULL, delimiter);
            while (token != NULL)
            {
                limit = 6;
                int length = strlen(token);
                if (token[length - 1] == ',')
                {
                    token[length - 1] = '\0';
                    char *subtoken = (char*) malloc(SIZE);
                    memcpy(subtoken, &token[1], strlen(token));
                    subtoken[strlen(token)] = '\0';
                    token = strdup(subtoken);
                    limit = 4;
                }
                else if (token[0] == '-')
                {
                    is_negative = TRUE;
                    char subtoken[strlen(token) - 1];
                    memcpy( subtoken, &token[1], strlen(token));
                    subtoken[strlen(token) - 1] = '\0';
                    token = strdup(subtoken);
                }
                strcat(outputLineData, convert_binary_and_expand(token, is_negative, limit));
                token = strtok(NULL, delimiter);
            }
        }
        else if (opCodeValue == 8)
        {
            strcat(outputLineData, current_op_code);
            const char delimiter[2] = " ";
            char *token;
            int limit = 10;
            Boolean is_negative = FALSE;
            token = strtok(input_data, delimiter);
            token = strtok(NULL, delimiter);
            while (token != NULL)
            {
                int length = strlen(token);
                if (token[length - 1] == ',')
                {
                    token[length - 1] = '\0';
                    limit = 4;
                }
                else if (token[0] == '-')
                {
                    is_negative = TRUE;
                    char subtoken[strlen(token) - 1];
                    memcpy( subtoken, &token[1], strlen(token));
                    subtoken[strlen(token) - 1] = '\0';
                    token = strdup(subtoken);
                }
                strcat(outputLineData, convert_binary_and_expand(token, is_negative, limit));
                token = strtok(NULL, delimiter);
            }
            strcat(outputLineData, convert_binary_and_expand("0", FALSE, 4));
        }
        else if (opCodeValue == 9 || opCodeValue == 10)
        {
            strcat(outputLineData, current_op_code);
            const char delimiter[2] = " ";
            char *token;
            int limit;
            Boolean is_negative = FALSE;
            token = strtok(input_data, delimiter);
            token = strtok(NULL, delimiter);
            while (token != NULL)
            {
                limit = 10;
                int length = strlen(token);
                if (token[length - 1] == ',')
                {
                    token[length - 1] = '\0';
                    char *subtoken = (char*) malloc(SIZE);
                    memcpy(subtoken, &token[1], strlen(token));
                    subtoken[strlen(token)] = '\0';
                    token = strdup(subtoken);
                    limit = 4;
                }
                else if (token[0] == '-')
                {
                    is_negative = TRUE;
                    char subtoken[strlen(token) - 1];
                    memcpy( subtoken, &token[1], strlen(token));
                    subtoken[strlen(token) - 1] = '\0';
                    token = strdup(subtoken);
                }
                strcat(outputLineData, convert_binary_and_expand(token, is_negative, limit));
                token = strtok(NULL, delimiter);
            }
        }
        else if (opCodeValue >= 11 && opCodeValue <= 15)
        {
            strcat(outputLineData, current_op_code);
            const char delimiter[2] = " ";
            char *token;
            int limit;
            Boolean is_negative = FALSE;
            token = strtok(input_data, delimiter);
            token = strtok(NULL, delimiter);
            while (token != NULL)
            {
                limit = 3;
                int length = strlen(token);
                if (token[length - 1] == ',')
                {
                    token[length - 1] = '\0';
                    char *subtoken = (char*) malloc(SIZE);
                    memcpy(subtoken, &token[1], strlen(token));
                    subtoken[strlen(token)] = '\0';
                    token = strdup(subtoken);
                    limit = 4;
                }
                else if (token[0] == '-')
                {
                    is_negative = TRUE;
                    char subtoken[strlen(token) - 1];
                    memcpy( subtoken, &token[1], strlen(token));
                    subtoken[strlen(token) - 1] = '\0';
                    token = strdup(subtoken);
                }
                strcat(outputLineData, convert_binary_and_expand(token, is_negative, limit));
                token = strtok(NULL, delimiter);
            }
            strcat(outputLineData, convert_binary_and_expand("0", FALSE, 3));
        }
        strrev(outputLineData);
        int start_length = strlen(outputLineData);
        outputLineData[start_length] = '0';
        outputLineData[start_length + 1] = '0';
        outputLineData[start_length + 2] = '\0';
        strrev(outputLineData);
        puts(outputLineData);
        write_in_file(convertValue('B', 'H', outputLineData), APPEND, NEWLINE);
    }
    clear_read_cache();
    clear_write_cache();
}

// Takes an input string and a boolean indicates the negative sign and expand limit
char * reverse_bits(char *binary);
char * convert_binary_and_expand(char input[], Boolean is_negative, int limit)
{
    char *output = convertValue('D', 'B', input);
    char expand_bit[2] = "0";
    if (is_negative)
    {
        strcpy(expand_bit, "1");
        output = reverse_bits(output);
        int negative_limit = strlen(output);
        int value = atoi(convertValue('B', 'D', output)) + 1;
        output = convert_binary_and_expand(Itoa(value, 2), FALSE, negative_limit);
    }
    output = strrev(output);
    int length = strlen(output);
    while (length++ < limit)
    {
        strcat(output, expand_bit);
    }
    return strrev(output);
}

// Reverses bits of a binary number
char * reverse_bits(char *binary)
{
    int length = strlen(binary);
    char *reversed_binary = (char *) malloc(length);
    for (int i = 0; i < length; ++i)
    {
        *(reversed_binary + i) = binary[i] == '0' ? '1' : '0'; 
    }
    return reversed_binary;
}

#endif //DIGITALLOGICPROJECT_ENCRYPTER_H
